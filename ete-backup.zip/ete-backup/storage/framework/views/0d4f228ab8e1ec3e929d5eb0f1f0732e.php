<!DOCTYPE html>
<html>
<head>
    <title>Laravel 10 Generate PDF Example - fundaofwebit.com</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Analysis Report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <table class="table table-bordered">
        <thead>
            <tr>
                
                <th>Party</th>
                <th>FollowerCounts</th>
                <th>YoungUsers</th>
                <th>MiddledAgeUsers</th>
                <th>MaleFollowers</th>
                <th>FemaleFollowers</th>
                <th>TransgenderFollowers</th>
                <th>AppreciatePostCount</th>
                <th>LikePostCount</th>
                <th>CarePostCount</th>
                <th>UnlikesPostCount</th>
                <th>SadPostCount</th>
                <th>IssuedResolved</th>
                <th>PostFrequency</th>
                <th>Sentiments</th>
                <th>ResponseTime</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $partyDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td><?php echo e($party['partyname']); ?></td>
                <td><?php echo e($party['followersCount']); ?></td>
                <td><?php echo e($party['youngUsers']); ?></td>
                <td><?php echo e($party['middledAgeUsers']); ?></td>
                <td><?php echo e($party['maleFollowers']); ?></td>
                <td><?php echo e($party['femaleFollowers']); ?></td>
                <td><?php echo e($party['transgenderFollowers']); ?></td>
                <td><?php echo e($party['appreciatePostCount']); ?></td>
                <td><?php echo e($party['likePostCount']); ?></td>
                <td><?php echo e($party['carePostCount']); ?></td>
                <td><?php echo e($party['unlikesPostCount']); ?></td>
                <td><?php echo e($party['sadPostCount']); ?></td>
                <td><?php echo e($party['issuedResolvedCount']); ?></td>
                <td><?php echo e($party['postFrequency']); ?></td>
                <td><?php echo e($party['sentiments']); ?></td>
                <td><?php echo e($party['responseTime']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html><?php /**PATH C:\xampp\htdocs\nxtgov_backend\resources\views/reports/partyreports.blade.php ENDPATH**/ ?>