<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('notifications', function (Blueprint $table) {
            $table->boolean('isBroadcast')->default(false);
            $table->dropColumn(['broadcast_message', 'broadcast_image', 'broadcast_url']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('notifications', function (Blueprint $table) {
            $table->dropColumn('isBroadcast');
            $table->string('broadcast_message')->nullable();
            $table->string('broadcast_image')->nullable();
            $table->string('broadcast_url')->nullable();
        });
    }
};
